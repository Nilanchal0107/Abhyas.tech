package tech.abhyas.trainer.resume;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

class ProjectQuestionServiceTest {
    private static final JsonMapper JSON = JsonMapper.builder().build();

    private static List<ProjectQuestionService.Question> parse(String json) { return ProjectQuestionService.questions(JSON.readTree(json)); }

    @Test
    void keepsAQuestionWithThreeToSixTrimmedFacts() {
        var qs = parse("{\"questions\":[{\"text\":\" Why Redis? \",\"keyFacts\":[\" a \",\"b\",\"\",\"c\",\"d\",\"e\",\"f\",\"g\"]}]}");
        assertThat(qs).hasSize(1);
        assertThat(qs.get(0).text()).isEqualTo("Why Redis?");
        assertThat(qs.get(0).keyFacts()).containsExactly("a", "b", "c", "d", "e", "f");
    }

    @Test
    void dropsQuestionsWithTooFewFactsNoTextOrADuplicateAndStopsAtEight() {
        assertThat(parse("{\"questions\":[{\"text\":\"Q\",\"keyFacts\":[\"a\",\"b\"]},{\"text\":\"\",\"keyFacts\":[\"a\",\"b\",\"c\"]},{\"keyFacts\":[\"a\",\"b\",\"c\"]},{\"text\":\"Q\"}]}")).isEmpty();
        assertThat(parse("{\"questions\":[{\"text\":\"Same\",\"keyFacts\":[\"a\",\"b\",\"c\"]},{\"text\":\"same\",\"keyFacts\":[\"a\",\"b\",\"c\"]}]}")).hasSize(1);
        StringBuilder many = new StringBuilder("{\"questions\":[");
        for (int i = 0; i < 12; i++) many.append(i > 0 ? "," : "").append("{\"text\":\"Q").append(i).append("\",\"keyFacts\":[\"a\",\"b\",\"c\"]}");
        assertThat(parse(many.append("]}").toString())).hasSize(ProjectQuestionService.WANTED);
        assertThat(parse("{\"other\":1}")).isEmpty();
    }
}
