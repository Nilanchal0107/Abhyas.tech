package tech.abhyas.trainer.session;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.mysql.MySQLContainer;
import tech.abhyas.trainer.common.ApiException;
import tech.abhyas.trainer.resume.ResumeService;
import tools.jackson.databind.json.JsonMapper;

/** Progress view (skill-bank ticket 14) on a real MySQL 8. Skipped when Docker is not installed. */
@Testcontainers(disabledWithoutDocker = true)
@SpringBootTest(properties = {"app.jwt.secret=test-secret-test-secret-test-secret-123", "app.ai.groq-key=", "app.ai.google-key="})
class ProgressDbTest {
    @Container
    static final MySQLContainer MYSQL = new MySQLContainer("mysql:8.0").withUrlParam("serverTimezone", "UTC");

    @DynamicPropertySource
    static void db(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", MYSQL::getJdbcUrl);
        r.add("spring.datasource.username", MYSQL::getUsername);
        r.add("spring.datasource.password", MYSQL::getPassword);
    }

    @Autowired JdbcTemplate jdbc;
    @Autowired ResumeService resumes;
    @Autowired ProgressController progress;

    private long user(String login) {
        jdbc.update("INSERT INTO app_user (login_id, password_hash) VALUES (?, 'x')", login);
        return jdbc.queryForObject("SELECT id FROM app_user WHERE login_id = ?", Long.class, login);
    }

    /** One completed session with a bank question of the skill answered with the given score out of 2. */
    private void session(long me, long resume, long skill, String tag, double score) {
        jdbc.update("INSERT INTO bank_question (type, skill_id, text_template, source, text_hash) VALUES ('fill_blank', ?, 'Q?', 'seed', SHA2(?, 256))", skill, tag);
        long bank = jdbc.queryForObject("SELECT id FROM bank_question WHERE text_hash = SHA2(?, 256)", Long.class, tag);
        jdbc.update("INSERT INTO question (resume_id, bank_question_id, type, text, source, text_hash) VALUES (?, ?, 'fill_blank', 'Q?', 'bank', SHA2(?, 256))", resume, bank, tag);
        long q = jdbc.queryForObject("SELECT id FROM question WHERE text_hash = SHA2(?, 256) AND resume_id = ?", Long.class, tag, resume);
        jdbc.update("INSERT INTO practice_session (user_id, resume_id, status, max_marks, total_marks, completed_at) VALUES (?, ?, 'completed', 80, 10, UTC_TIMESTAMP(3))", me, resume);
        long s = jdbc.queryForObject("SELECT MAX(id) FROM practice_session", Long.class);
        jdbc.update("INSERT INTO attempt (session_id, question_id, position, max_marks, score) VALUES (?, ?, 1, 2, ?)", s, q, score);
    }

    @Test
    void weakestSkillFirstStudyNextAndOwnDataOnly() {
        long me = user("prog-me"), other = user("prog-other");
        long role = jdbc.queryForObject("SELECT MIN(id) FROM role WHERE owner_user_id IS NULL", Long.class);
        jdbc.update("INSERT IGNORE INTO skill (name) VALUES ('ProgA'), ('ProgB'), ('ProgGap')");
        long a = jdbc.queryForObject("SELECT id FROM skill WHERE name = 'ProgA'", Long.class);
        long b = jdbc.queryForObject("SELECT id FROM skill WHERE name = 'ProgB'", Long.class);
        long gap = jdbc.queryForObject("SELECT id FROM skill WHERE name = 'ProgGap'", Long.class);
        jdbc.update("INSERT INTO role_skill (role_id, skill_id) VALUES (?, ?)", role, gap);
        long resume = (Long) resumes.save(me, "r.pdf", role, null, "openresume", JsonMapper.builder().build().readTree("{\"experience\":[],\"projects\":[],\"skills\":[]}")).get("id");

        session(me, resume, a, "a1", 2);
        session(me, resume, b, "b1", 0);
        session(me, resume, b, "b2", 1);

        Map<String, Object> out = progress.progress(me, resume);
        List<Map<String, Object>> skills = (List<Map<String, Object>>) out.get("skills");
        assertThat(out.get("sessionCount")).isEqualTo(3);
        assertThat(skills).extracting(s -> s.get("skill")).containsExactly("ProgB", "ProgA"); // weakest first
        assertThat(skills.get(0).get("percent")).isEqualTo(25); // 1 of 4 marks over two sessions
        assertThat((List<?>) skills.get(0).get("bySession")).hasSize(2);
        assertThat((List<Map<String, Object>>) out.get("studyNext")).extracting(n -> n.get("skill") + ":" + n.get("reason"))
                .contains("ProgB:low-marks", "ProgGap:gap").doesNotContain("ProgA:low-marks"); // ProgA has full marks

        assertThatThrownBy(() -> progress.progress(other, resume)).isInstanceOf(ApiException.class); // another user's resume is 404
    }
}
