package tech.abhyas.trainer.resume;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class SkillMatcherTest {
    @Test
    void matchesWholeWordsIgnoringCase() {
        assertThat(SkillMatcher.found("Built services in JAVA and Spring Boot.", "Java")).isTrue();
        assertThat(SkillMatcher.found("Skills: React, Redux", "react")).isTrue();
        assertThat(SkillMatcher.found("RESTful basics", "RESTful basics")).isTrue();
        assertThat(SkillMatcher.found("Wrote a REST API (Node.js).", "Node.js")).isTrue();
        assertThat(SkillMatcher.found("Set up CI/CD, then deployed", "CI/CD")).isTrue();
    }

    @Test
    void doesNotMatchInsideOtherWords() {
        assertThat(SkillMatcher.found("Wrote JavaScript", "Java")).isFalse();
        assertThat(SkillMatcher.found("Tuned MySQL", "SQL")).isFalse();
        assertThat(SkillMatcher.found("Reactive streams", "React")).isFalse();
        assertThat(SkillMatcher.found("Worked at Google on Django", "Go")).isFalse();
        assertThat(SkillMatcher.found("Wrote C++ and C# code", "C")).isFalse();
        assertThat(SkillMatcher.found("Used RESTful services", "REST")).isFalse();
        assertThat(SkillMatcher.found("Ran R scripts", "R")).isTrue();
        assertThat(SkillMatcher.found("Built a REST API", "R")).isFalse();
    }

    @Test
    void shortTermsAreCaseSensitive() {
        assertThat(SkillMatcher.found("Services written in Go", "Go")).isTrue();
        assertThat(SkillMatcher.found("ready to go live", "Go")).isFalse();
    }
}
