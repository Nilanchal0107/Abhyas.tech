package tech.abhyas.trainer.session;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.junit.jupiter.api.Test;

/** Placeholder filling, skill matching and the personal-text check that keeps one user's details out of the shared bank (ticket 17). */
class PracticeBankTest {

    @Test
    void placeholdersAreFilledFromTheResumeAndAnEmptyOneRejectsTheTemplate() {
        assertThat(PracticeBank.fillPlaceholders("In {project} you used {skill}. Why?", "Order Service", "Redis", null, null, null)).isEqualTo("In Order Service you used Redis. Why?");
        assertThat(PracticeBank.fillPlaceholders("At {company} you wrote: '{bullet}'. How did you measure it?", null, null, "Acme", "Cut latency 40%", null))
                .isEqualTo("At Acme you wrote: 'Cut latency 40%'. How did you measure it?");
        assertThat(PracticeBank.fillPlaceholders("Tell me about {theme} on {project}.", null, null, null, null, "deadline pressure")).isNull(); // no project to name
        assertThat(PracticeBank.fillPlaceholders("No placeholders here.", null, null, null, null, null)).isEqualTo("No placeholders here.");
    }

    @Test
    void aSlotsMixIsAboutEightyPercentResumeSkillsAndTwentyPercentGapAndFillsInWhenOneSideRunsShort() {
        List<Integer> rows = List.of(1, 2, 3, 4, 5, 6, 7, 8, -1, -2, -3); // positive = on the resume, negative = role gap
        java.util.function.Predicate<Integer> onResume = n -> n > 0;
        assertThat(PracticeBank.mix(rows, 5, 1, onResume).subList(0, 5)).containsExactly(1, 2, 3, 4, -1);
        assertThat(PracticeBank.mix(rows, 2, 1, onResume).subList(0, 2)).containsExactly(1, 2); // 20% of 2 rounds to none
        assertThat(PracticeBank.mix(List.of(1, 2, 3, 4, 5, 6), 5, 1, onResume).subList(0, 5)).containsExactly(1, 2, 3, 4, 5); // no gap rows: resume only
        assertThat(PracticeBank.mix(List.of(-1, -2, -3), 3, 1, onResume)).containsExactly(-1, -2, -3); // nothing on the resume: gap fills in
        assertThat(PracticeBank.mix(rows, 5, 0, onResume)).isEqualTo(rows); // behavioral rows are left as they are
    }

    @Test
    void skillsAreMatchedAsWholeWordsIgnoringCase() {
        assertThat(PracticeBank.mentions("Built REST APIs with Spring Boot and MySQL", "spring boot")).isEqualTo(1);
        assertThat(PracticeBank.mentions("Wrote JavaScript tests", "Java")).isZero();
        assertThat(PracticeBank.mentions("Used C++ and C#", "C++")).isEqualTo(1);
        assertThat(PracticeBank.mentions("Redis, redis and REDIS", "Redis")).isEqualTo(3);
    }
}
