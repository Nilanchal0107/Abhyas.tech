# 10: Remove the old AI question generation

**What to build:** Delete per-part AI generation in `SessionService.generate`, `PracticeBank.learn` (AI rows into the shared bank), the `key_fact` worker, and the dead code and tests that go with them. Update Export JSON if fields changed.

**Blocked by:** 09

**Status:** done (manual checks passed, 5 October 2026). Left open: the MySQL tests and the V6 migration test were not run (no Docker). `key_fact` and `resume_point.key_facts_*` were dropped (V6), not kept. `/code-review` was not run. Bank drafts renumber to V7/V8.

- [x] No dead code or unused columns left (or columns kept on purpose, noted here).
- [x] All tests pass.
- [x] Docs match the code.
