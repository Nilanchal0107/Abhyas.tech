# 03: Fixed list of target roles

**What to build:** Only the 11 starter roles in the seed. Decide whether "add a missing role" and the AI role-skill draft stay.

**Blocked by:** none

**Status:** done (manual checks passed 4 October 2026). Left open: `RoleSearchDbTest` not run (no Docker).

- [x] `roles_starter.csv` holds the 11 roles; `V3__narrow_starter_roles.sql` deletes the other 31 starter roles (keeps a role a resume targets; keeps all skills).
- [ ] `RoleSearchDbTest` run on MySQL (written, skipped without Docker).
- [x] Owner decides: remove "add a missing role" (4 October 2026).
- [x] Removed: `RoleService`, `POST /roles`, `POST /roles/draft-skills`, `AddRolePanel.jsx`, their tests; docs updated (prd, api-contracts, trd, UI-UX, wireframes). Roles added earlier stay, private to their user.
- [x] Manual: on Upload, search "zzz": the field says "No role found. Try …" and there is no "Add a missing role" button. Search "SDE": Software Engineer shows.
- [x] Manual: restart the backend (Flyway runs V3), search roles: only the 11 show (plus any role a resume of yours already used).
