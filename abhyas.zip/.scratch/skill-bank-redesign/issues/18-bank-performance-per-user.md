# 18: Keep a user's performance on bank questions across resumes

**What to build:** Bank questions are shared by skill and by role, but `question` (with `mastered`, `last_score`, `last_asked_at`) is per resume (`database-schema.md` 3.11). If a user uploads a second resume for another role, a bank question they already mastered would come back as new. The owner wants performance stored and mastered questions not repeated (rest one month, then allowed).

**Question for the owner (needs-info):** should mastery of a bank question follow the **user** (across all their resumes), or stay per resume (a new resume starts fresh, prd v7 to v8)? Recommendation: follow the user for bank questions (they are not about the resume); project questions stay per resume. This is a schema change (a per-user performance table keyed by `user_id` + `bank_question_id`), so it needs a migration and doc updates.

**Blocked by:** owner decision, 07

**Status:** done (owner decided 5 October 2026: mastery of bank questions follows the user; project questions stay per resume). Left open: Export JSON was not changed because it reads attempts, not question performance; the Resume list mastered count still uses the per-resume copy; the new database tests were not run (no Docker), only the manual checks were.

- [x] Owner decides: per user (bank questions), per resume (project questions).
- [x] Migration, session building, grading and Export JSON read and write the per-user performance row.
- [x] Every query scoped to the signed-in user; another user's data returns 404.
- [x] Account deletion removes the new rows (the deletion test covers every user table).
- [x] Docs: `prd.md` FR-13 and FR-14, `database-schema.md`, `trd.md` 7.2, `CONTEXT.md` if "mastered" changes meaning.
- [x] Manual: master a bank question on resume A, start a session on resume B; it does not appear.
