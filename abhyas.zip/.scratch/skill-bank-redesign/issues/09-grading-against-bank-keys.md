# 09: Grade open answers against the question's own key facts

**What to build:** Brief and voice technical answers are checked against the key facts stored on the question (ticket 08), not the resume point's. The keyword fallback uses the same lists.

**Blocked by:** 08

**Status:** done (manual checks passed, 5 October 2026). No code change was needed: `GradingService.facts()` already read the question's own `key_facts` first. Left open: no test proves own facts win over the point's (`facts()` is private, no MySQL/Docker for a DB test), and old template questions without `key_facts` still fall back to their resume point's facts until ticket 10. The optional keyword-fallback manual check was not confirmed.

- [x] Checklist items come from the question's key facts.
- [x] The evidence rule and Java-summed marks are unchanged.
- [x] Manual: answer one brief and one voice question; the report shows sensible ticks.
