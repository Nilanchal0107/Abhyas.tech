# 12: Show keyword grading and allow a regrade

**What to build:** D9. An answer with `graded_by = 'fallback'` shows "Graded without AI" in the report, with a **Regrade** button. Regrade re-runs Groq marking and Gemma feedback for that answer when AI is available, updates the session total, and lets the mark count toward mastery. `api-contracts.md` gains `gradedBy` on graded attempts and the regrade endpoint.

**Blocked by:** none (can go before 04–10)

**Status:** done (manual check passed 4 October 2026). Left open: the regrade DB test is not run (no Docker). The field is `gradedWithoutAi` (boolean), not the raw `gradedBy`.

- [x] Report shows the note only on keyword-graded answers.
- [x] Regrade is scoped to the user's own attempt (404 otherwise) and refused while AI is unavailable, with an inline message. (DB test written, not run without Docker.)
- [x] Total, marks by part and mastery update after a regrade (the grading worker recomputes them).
- [x] prd FR-20, api-contracts, UI-UX 7.4, trd, database-schema updated.
- [x] Manual: run a session with no Groq key, see the note, add the key, regrade.
