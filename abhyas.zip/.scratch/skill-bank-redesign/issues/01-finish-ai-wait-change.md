# 01: Finish the short-limit wait in AiClient

**What to build:** `AiClient.json()` waits out a cooldown or Retry-After of up to 15 seconds. A longer Retry-After fails at once instead of waiting part of it and retrying (the same rule for `jsonPatient`, with its 60 s cap).

**Blocked by:** none

**Status:** done (manual check passed, 4 October 2026)

- [x] Owner decides: keep (4 October 2026).
- [x] A Retry-After above 15 s fails at once, with no wait.
- [x] `AiClientTest`, `GemmaFeedbackTest`, `ResumeFallbackTest` pass (171 run, 0 failures, 41 MySQL tests skipped without Docker).
- [x] Manual: start a session, then upload a resume right away; the parse succeeds.
