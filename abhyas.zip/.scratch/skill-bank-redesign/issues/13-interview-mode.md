# 13: Interview mode

**What to build:** D10. A second session mode: about 6 open questions (technical from ticket 08 plus behavioral from the bank), answered by voice or typing. After each answer the AI asks one follow-up based on what the user said; the follow-up answer is graded with the main one. Then marks, Gemma feedback per answer and a coaching report. Reuses transcription, checklist grading and the report screen.

**Blocked by:** 08, 09 (needs the per-question key facts)

**Status:** done (manual checks passed, 5 October 2026) (owner settled the design 5 October 2026: 6 questions, 1 follow-up each, 3 minutes per answer, 10 marks per question (5 typed), counts toward mastery). Left open: `/code-review` and the MySQL tests (no Docker, so no DB test covers `V7` or the follow-up SQL) were not run.

- [x] Owner settles: number of questions, one or two follow-ups, timer or not, marks per question, whether it counts toward mastery.
- [x] `practice_session.mode` (quiz or interview); one unfinished session per user still holds.
- [x] Follow-up written by Groq from the question, key facts and the answer; never assumes details the resume does not state.
- [x] Home lets the user pick the mode; History shows it.
- [x] Docs: prd (new FR), trd, api-contracts, database-schema, UI-UX and wireframes, CONTEXT ("Interview mode").
- [x] Manual: run one interview end to end by voice and one by typing.
