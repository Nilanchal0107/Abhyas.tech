# 08: One AI call per resume for the open questions

**What to build:** After a resume is saved, one background AI call writes about 8 technical open questions about the user's projects and experience, each with 3–6 key facts stored on the question (`question.key_facts`). A session uses 1 of them as a brief and 2 as voice questions (ticket 17, owner 5 October 2026). This removes the per-point key-facts worker. Retried later if it fails; until then the existing templates fill the slots.

**Blocked by:** 07

**Status:** done (manual checks passed, 5 October 2026). Left open: no MySQL test covers the new service (no Docker; `KeyFactDbTest` was deleted, not replaced). The 1 brief + 2 voice split is ticket 17, so up to 3 project questions can fill the technical brief slots until then. `SessionService.generate` and the `key_fact` table / `resume_point.key_facts_*` columns are dead until ticket 10.

- [x] One call per resume; retried later if it fails.
- [x] Questions never assume details the resume does not state (FR-9).
- [x] Per-point key-facts drafting removed.
- [x] Manual: upload the test resume; the open questions are about its projects and their key facts make sense.
