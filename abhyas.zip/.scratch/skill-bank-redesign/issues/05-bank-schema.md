# 05: Bank schema: skill, difficulty, review status

**What to build:** Every bank question has a skill (or a theme for behavioral), a type and a difficulty, and sessions can tell reviewed rows apart.

**Blocked by:** 02

**Status:** done (no change needed, 4 October 2026)

- [x] Difficulty: `bank_question.difficulty ENUM('easy','medium','hard')` already exists in V1. It is D5's basic/intermediate/advanced under other names, so it is reused, not renamed.
- [x] Reviewed: `source = 'seed'` means reviewed (a seed row reaches the database only through a migration the owner moves in after review). `source = 'ai'` rows come from `PracticeBank.learn`, which ticket 10 removes. No new column.
- [x] Theme, key facts and keywords columns already exist.
- [x] Seed rows are checked by the same rules as AI questions (`gen_bank.py check()`).
