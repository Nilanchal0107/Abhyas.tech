# 14: Progress view (proposed)

**What to build:** "Guide me" across sessions: the weakest skills over all completed sessions of a resume, marks per skill over time, and a short "study next" list (lowest skills plus gap skills). Built from stored attempts, no AI needed.

**Blocked by:** 07 (questions carry a skill)

**Status:** in-review (built 5 October 2026, waiting for the manual check)

- [x] Owner approves.
- [x] Scoped to the user's own data (query joins `practice_session.user_id`; another user gets 404). DB test written but not run: no Docker here.
- [ ] Manual: after three sessions, the weakest skills match the reports.
