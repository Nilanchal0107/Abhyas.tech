# 06: Write and review the bank (objective, brief and behavioral)

**What to build:** A practice bank for **every skill of the 11 starter roles** (owner, 4 October 2026; it started as Full Stack only). Per skill: 10 multiple-correct and 10 fill-in-the-blank questions (3 easy, 4 medium, 3 hard) and 5 technical briefs with 3 key facts and keywords each. Soft skills (Communication, Critical Thinking) get only the 5 briefs. Plus 20 behavioral questions by theme. The owner reviews `seed-draft/review.md`; reviewed rows are loaded by moving `V4__starter_bank.sql` into `db/migration/`.

**Files:** `gen_bank.py` (checks and output), `bank_common.py` (helpers), data in `bank_fullstack.py`, `bank_software.py`, `bank_frontend.py`, `bank_data.py`, `bank_dataeng.py`, `bank_devops.py`.

**Blocked by:** 03, 05

**Status:** in-progress (all drafted, waiting for review)

- [x] All 74 skills drafted: 720 multiple-correct, 720 fill-in-the-blank, 370 briefs, plus 20 behavioral (1,830 rows).
- [x] The generator checks shape, counts per skill and level, duplicates, and that every role skill is covered. No text appears twice; none collides with a PracticeBank placeholder.
- [ ] The owner reviewed the keys in `review.md` (each skill heading names its data file). Skills can be reviewed and loaded one role at a time if preferred.
- [x] No text copied from interview-question sites (written from general knowledge).
- [ ] `V4__starter_bank.sql` moved to `db/migration/`; backend restart loads it (Flyway). Not run against MySQL yet.

**Note for ticket 07:** superseded on 5 October 2026: see ticket 17 (1 AI project brief, 3 bank technical briefs, 2 AI project voice). Review and loading in two waves: ticket 16.
