# 04: Skill aliases and matching inside bullets

**What to build:** A `skill_alias` table with seed aliases, and matching of skill names and aliases (whole words, ignoring case) in Skills lines and in project and experience bullets. The role skills check shows the bullet as evidence instead of repeating the skill name.

**Blocked by:** 02

**Status:** done (manual checks passed 5 October 2026). Left open: `ResumeListDbTest` not run (no Docker). Bank drafts in seed-draft must be renumbered V5/V6 when moved.

- [x] A migration adds `skill_alias`; aliases are seeded for every target-role skill.
- [x] "RESTful basics" counts for REST APIs; "React" in a project bullet counts for React.
- [x] No false hits for short names (C, Go, R) inside other words.
- [x] Unit tests for the matcher.
- [x] Manual: the test resume against Backend and Frontend Developer shows the expected evidence.
