# 19: A session always has its 19 questions

**What to build:** 19 questions is mandatory (owner, 5 October 2026). Session building must fill every slot even when a skill has too few unrested bank questions, the resume has few skills, or AI is down. Fill order for a slot: (1) unmastered / weak first, (2) rested or new bank questions of the user's skills, (3) the role's gap skills, (4) other skills of the same role, (5) generic `PracticeBank` templates. If AI cannot write the 1 brief and 2 voice project questions, use `PracticeBank` project templates for them. The count is always 19 (owner, 5 October 2026). This **replaces** the FR-20 rule "Whisper down at start leaves out the voice part (16 questions, 50 marks)": when Whisper is down, the 3 voice questions are answered through the browser's **Web Speech API** (`SpeechRecognition`), which gives a transcript in the browser. The transcript is sent like a Whisper transcript and graded as a voice answer (10 marks, mastery 8).

Points to settle when building:
- Web Speech works in Chrome and Edge, not reliably in Firefox. Chrome sends the audio to the browser vendor's servers, so the privacy note (`UI-UX.md`) must say so. We still store no audio.
- If Web Speech is also missing or the mic is denied: typed answer graded like a brief answer (5 marks, mastery 4 of 5), as FR-20 already says for a denied mic.
- Voice stats (`VoiceStats`: pace, fillers) need word timing. Web Speech gives no reliable timing, so for these answers use the recording length measured in the browser, or skip the stats and show no pace.

**Blocked by:** 07, 17

**Status:** done (manual checks passed, 5 October 2026). Open: the MySQL tests (including the new 19-question DB test) were not run, no Docker.

- [x] Test: a resume with 1 skill and an empty bank for it still produces 19 questions.
- [x] Test: AI unavailable still produces 19 questions.
- [x] No question appears twice in one session.
- [x] A slot filled from a gap skill or another role skill is labelled the way D4 says.
- [x] Whisper down: voice questions still appear; the user speaks through Web Speech and the transcript is graded as a voice answer.
- [x] No Web Speech or no mic: the typed fallback works.
- [x] No audio stored; docs (`prd.md` FR-15, FR-20, `trd.md`, `UI-UX.md` privacy text) match.
- [x] Manual: start a session with a very short resume; count 19. Then stop Whisper (bad key) and answer a voice question in Chrome.
