# 16: Review and load the bank in two waves

**What to build:** Questions are stored per skill and shared by every role that lists the skill (D12). Build and load the bank in two waves so the app has a usable bank sooner (owner, 5 October 2026):
- **Wave 1:** skills of the Software Development roles (Software Engineer, Backend, Frontend, Full Stack) and the AI roles (AI Engineer, Machine Learning Engineer). Owner reviews these in `seed-draft/review.md`, then they are loaded as `V4__starter_bank.sql`.
- **Wave 2:** the rest (Data Analyst, Data Scientist, Data Engineer, DevOps, Cloud). Reviewed later and loaded as `V5__starter_bank_wave2.sql`.

The generator (`gen_bank.py`) must be able to write one output file per wave. A skill used by both waves is loaded once, in wave 1.

**Blocked by:** 06

**Status:** in-progress (generator and review split done 5 October 2026; waiting for the owner's wave 1 review)

- [x] Generator writes wave 1 (`review.md`, `V4__starter_bank.sql`: 43 skills + 20 behavioral, 1,095 rows) and wave 2 (`review_wave2.md`, `V5__starter_bank_wave2.sql`: 31 skills, 735 rows) separately; shared skills appear only in wave 1; its checks (counts, levels, duplicates, role coverage) pass for each wave.
- [x] `review.md` is split or marked by wave, so the owner can review wave 1 alone.
- [ ] Owner reviewed wave 1; the wave 1 migration is in `db/migration/`.
- [ ] Backend restart loads it (Flyway). Not run against MySQL yet: say so if Docker or MySQL is unavailable.
- [x] A skill shared by several roles has one set of rows, not one per role.
- [ ] Wave 2 stays in `seed-draft/` until reviewed.
