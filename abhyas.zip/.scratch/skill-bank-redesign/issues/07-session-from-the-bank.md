# 07: Objective and behavioral parts from the bank

**What to build:** Session start fills multiple-correct, fill-in-the-blank and behavioral slots from reviewed bank rows for the user's matched skills and the role's gap skills (D4), keeping repetition of weak questions (FR-13). Gap-skill questions are labelled in the UI. No AI call for these parts.

**Blocked by:** 04, 06

**Status:** done (manual checks passed, 5 October 2026)

- [x] The mix of matched and gap skills follows D4 (`PracticeBank.mix`, about 80/20).
- [x] Weak questions come back; mastered ones rest.
- [x] Session start makes no AI call for these parts.
- [x] A skill with no reviewed rows falls back to the existing generic templates.
- [x] Manual: start two sessions; questions fit the resume's skills, and gap ones are labelled.

**Open:** technical brief and voice questions still use AI until ticket 08. The unused multiple-correct and fill-in-the-blank prompts in `SessionService.generate` are left for ticket 10 to delete. The Docker/MySQL tests (`SessionDbTest` etc.) were not run by me.
