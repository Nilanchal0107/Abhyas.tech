# 11: Final manual pass

**What to build:** An end-to-end run with the test resume against the owner's target roles, in both modes.

**Blocked by:** 10, 12, 13

**Status:** needs-triage

- [ ] Upload → skills check → quiz session → report → export.
- [ ] Upload → interview session → report.
- [ ] Groq calls per new resume: parse (if needed), 1 open-question call and grading only.
