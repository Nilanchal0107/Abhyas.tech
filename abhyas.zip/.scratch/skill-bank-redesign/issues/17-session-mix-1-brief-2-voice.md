# 17: Session mix: 16 bank questions, 1 AI brief, 2 AI voice

**What to build:** Change the session layout (owner, 5 October 2026). 19 questions, 80 marks:

| Part | Count | From the bank | From AI (about the user's projects) |
|---|---|---|---|
| Multiple-correct | 5 | 5 | 0 |
| Fill-in-the-blank | 5 | 5 | 0 |
| Brief | 6 | 3 technical + 2 behavioral | 1 |
| Voice | 3 | 1 behavioral | 2 |

This replaces "2 AI briefs + 1 technical voice" in ticket 06's note, spec D3 and `trd.md` 7.2. The one AI call per resume (ticket 08) writes about 8 project questions, each with its own key facts; a session takes 1 brief and 2 voice from them. Mastered questions still rest one month, then may return (FR-13 unchanged).

**Docs to update when built:** `prd.md` section 9 and FR-9, FR-13, FR-20; `trd.md` 7.2 and Step 3; `api-contracts.md` if the question source is exposed; `wireframes.md` / `UI-UX.md` if the practice screen text changes.

**Blocked by:** 16 (wave 1 loaded), 07, 08

**Status:** code done, manual check pending

- [x] A session has exactly 5 + 5 + 6 + 3 questions with the split in the table.
- [x] Project questions already answered and mastered rest for one month like any other.
- [x] Voice unavailable: voice part left out (16 questions, 50 marks), as FR-20 says today.
- [x] Docs above match the code.
- [ ] Manual: start two sessions with the test resume; count the questions and check which come from the project.
