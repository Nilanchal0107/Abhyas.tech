# 15: Stop the key-facts worker from starving user requests

**What to build:** `KeyFactService.draftPending` sends one Groq call per resume point, about 1 s apart, each with the whole resume JSON. This trips Groq's 8,000 tokens/minute limit, the gate goes into cooldown and user requests (gap check, session start) fall back to templates (seen in the 5 October log). Add a gap between calls (like `app.grading.gemma-gap-millis`, about 7 s, in config) and make the worker skip a pass while the gate is in cooldown. Also find the cause of the `DataIntegrityViolationException` in `store()` (likely the point or resume was deleted or replaced during the AI call) and treat a vanished point as "skip", not a failed try.

**Temporary:** ticket 08 removes this worker. Keep the change small.

**Blocked by:** none

**Status:** done

- [x] Gap between key-facts calls comes from `application.yml`, not a constant.
- [x] The worker does nothing while Groq is cooling down; its try count does not go up for that.
- [x] A point that was deleted during the call does not log a database error or count as a failed try.
- [x] Unit test with the fake AI transport: calls are spaced; cooldown pauses the pass.
- [x] Manual: save the test resume; the log shows no burst of `RATE_LIMIT`, and starting a session right after still gets AI questions.
