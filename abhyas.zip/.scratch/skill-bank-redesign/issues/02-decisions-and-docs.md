# 02: Confirm decisions and update the docs

**What to build:** No code. Decisions D1–D11 are in `spec.md`. Update `prd.md` (FR-3, FR-8, FR-9, FR-16, FR-20, Section 5, Section 9, change log), `trd.md` (7.2 session building, Section 13 build steps), `database-schema.md`, `api-contracts.md` and `CONTEXT.md` terms as each ticket lands. The change-log entry for the decisions is written.

**Blocked by:** none

**Status:** in-progress

- [x] D1–D11 decided (owner, 4 October 2026), except the add-role question in ticket 03.
- [x] Target roles written down (the 11 in `database-schema.md` Section 12).
- [x] `prd.md` change-log entry for the decisions.
- [ ] Requirement sections rewritten as each ticket lands (not before, so the docs never describe code that does not exist).
