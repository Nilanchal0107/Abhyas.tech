# Skill bank redesign and Interview mode

**Idea (owner, 4 October 2026):** a session should feel like a mock interview for the chosen role, score the answers and guide what to fix. Questions with a right/wrong key come from a reviewed bank per skill; open questions about the user's own projects come from AI.

## Decisions (owner, 4 October 2026)
| # | Topic | Decision |
|---|---|---|
| D1 | Roles | The 11 starter roles (done: `V3__narrow_starter_roles.sql`). "Add a missing role" and the AI role-skill draft are **removed** (owner, 4 October 2026). |
| D2 | Skill matching | `skill_alias` table (RESTful → REST APIs) plus skill names and aliases found inside project and experience bullets, not only the Skills section. |
| D3 | Question source: **hybrid** | Multiple-correct and fill-in-the-blank come **only from the reviewed bank** (Java trusts their keys, so they must be right). **2 of the 3 voice questions and 1 of the 6 brief slots** are **written by AI about the user's projects**, with their own key facts; the other 3 technical brief slots come from reviewed bank briefs for the user's skills (owner, 5 October 2026, was: 2 AI briefs + 1 technical voice). Behavioral questions come from the bank (STAR, by theme). |
| D4 | Skill mix | About 80% of bank questions from skills the user has, 20% from the role's gap skills, shown as "likely to be asked for this role". |
| D5 | Difficulty | Every bank question has a level: the existing `difficulty` column, easy / medium / hard. "Reviewed" is `source = 'seed'` (ticket 05). |
| D6 | Bank size | Every skill of the 11 roles (74): per skill 10 multiple-correct, 10 fill-in-the-blank (3 easy, 4 medium, 3 hard) and 5 technical briefs with key facts; Communication and Critical Thinking get 5 scenario briefs only (owner, 4 October 2026). Reviewed by the owner. Nothing copied from interview-question sites. |
| D12 | Bank order | Bank questions are grouped by skill and shared by every role that lists the skill. Build the bank for **Software Development and AI roles first** (Software, Backend, Frontend, Full Stack, AI Engineer, Machine Learning Engineer); the other roles (Data, Cloud and DevOps) follow later (owner, 5 October 2026). |
| D7 | Open questions | **One AI call per resume** (after save, in the background) writes about 8 technical open questions about the user's projects, each with 3–6 key facts stored on the question. Replaces the per-point key-facts worker and the per-part generation calls. |
| D8 | AI providers | **Keep Groq + Gemma**: Groq marks, Gemma writes feedback and the report (unchanged). |
| D9 | Fallback label | **Not silent any more** (reverses prd v15): an answer graded by keyword matching shows a small "Graded without AI" note and a **Regrade** button that re-runs AI grading once AI is back. `graded_by` is still exported. |
| D10 | Interview mode | **New mode** next to the quiz session: about 6 open questions (technical about the user's projects plus behavioral), spoken or typed, one AI follow-up question per answer, then marks, feedback and a coaching report. The quiz session stays for drilling. Details to settle at ticket 13. |
| D11 | Session layout (quiz) | 19 questions, 80 marks: multiple-correct 5, blanks 5, brief 6 (1 AI project + 3 bank technical + 2 bank behavioral), voice 3 (2 AI project + 1 bank behavioral). Mastered questions rest one month, then may return (unchanged, owner 5 October 2026). |

## Why
- Groq's 8,000 tokens/minute limit: today one resume fires a key-facts call per point plus 4 generation calls, which trips the cooldown and drops sessions to templates. After D3 and D7: one call per resume, plus grading.
- A wrong AI key on a multiple-correct or blank question marks a right answer wrong. Reviewed bank keys remove that risk.
- The app is for one person: hiding keyword grading only hides useful information (D9).
- A 19-question quiz drills knowledge but is not an interview (D10).

## Also decided (owner, 5 October 2026)
- **D13:** mastery of bank questions follows the user across resumes; project questions stay per resume (ticket 18).
- **D14:** always 19 questions; Whisper down means voice answers through the Web Speech API (ticket 19).
- **D15:** Interview mode (ticket 13) is approved; its open design points remain.
- **D16:** Progress view ("guide me"): weakest skills across all sessions, trend per skill, a short "study next" list (ticket 14) is approved.

## Out of scope
- Phones, other job categories, a public question-submission flow.
