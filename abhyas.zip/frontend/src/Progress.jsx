import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import { api } from './api/client.js'

const REASON = { 'low-marks': 'Low marks so far', gap: 'Likely to be asked for this role' }

// "Guide me": the weakest skills over all completed sessions of one resume, and a short study-next list (ticket 14).
export default function Progress({ id }) {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    api(`/resumes/${id}/progress`).then(setData).catch((e) => setError(e.message))
  }, [id])

  if (error) return <p role="alert">! Error: {error}</p>
  if (!data) return <p>Loading your progress…</p>
  return (
    <>
      <p><Link to="/resumes">Back to resumes</Link></p>
      <h1>Your progress</h1>
      {data.skills.length === 0 ? (
        <p>No marked skills yet. Finish a practice session and your weakest skills show up here.</p>
      ) : (
        <>
          <h2>Study next</h2>
          <ul>{data.studyNext.map((s) => <li key={s.skillId}><strong>{s.skill}</strong> · {REASON[s.reason]}</li>)}</ul>
          <h2>Skills, weakest first ({data.sessionCount} completed {data.sessionCount === 1 ? 'session' : 'sessions'})</h2>
          <ul>
            {data.skills.map((s) => (
              <li key={s.skillId}>
                <strong>{s.skill}</strong> · {s.percent}% ({s.marks} of {s.maxMarks} marks)
                {' '}<span className="muted">over time: {s.bySession.map((x) => `${x.percent}%`).join(' → ')}</span>
              </li>
            ))}
          </ul>
        </>
      )}
    </>
  )
}
